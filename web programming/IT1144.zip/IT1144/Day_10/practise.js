console.log (6=="6");
console.log (6==="6");
console.log (15!=7);
console.log (20>5);
console.log (25<15);
console.log (11>=11);
console.log (54<=87);