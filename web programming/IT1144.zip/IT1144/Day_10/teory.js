==    -> Equal To (loose) //only the value
===   -> Equal To (Strict) //value and data type
!=    -> Not Equal To (loose)
!==   -> Not Equal To (Strict)
>     -> Greater than
<     -> Less than
>=    -> Greater than or equal
<=    -> Less than or equal 

&&  -> AND  -> both must be true
||  -> OR   -> either on is true
!   -> Not  -> flips the value (true -> false , false -> true)
