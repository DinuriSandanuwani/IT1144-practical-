let marks=55;
if (marks>=50){
	console.log("Pass")
}
  console.log("Countinue")