let marks=85;
if (marks>=75){
	console.log("You get grade'A'")
}
else if (marks>=65){
	console.log("You get grade'B'")
}
else if (marks>=55){
	console.log("You get grade'C'")
}
else if (marks>=45){
	console.log("You get grade'S'")
}
else {
	console.log("Fail")
}
  console.log("Countinue")