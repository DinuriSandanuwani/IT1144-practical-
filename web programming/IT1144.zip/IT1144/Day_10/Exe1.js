let marks=55;
if (marks>=50){
	console.log("Pass")
}
else {
	console.log("Fail")
}
  console.log("Countinue")