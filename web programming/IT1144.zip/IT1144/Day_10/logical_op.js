let marks=65;
let stuId=true;

console.log(marks>=50 && stuId===true);
console.log(marks<=90 || stuId===false);
console.log(!stuId);
console.log(marks>75 && stuId===true);
console.log(marks<65 || stuId===false);
console.log(stuId!=false);
