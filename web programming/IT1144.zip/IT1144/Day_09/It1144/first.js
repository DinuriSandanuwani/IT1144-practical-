console.log("Hi Dinu..");
console.log("I'm from Kuliyapitiya.");
console.log("I studied IT Degree Programme.");
console.log("I'm 20");

let studentName="Dinuri"
let age=20;
let homeTown="Kuliyapitiya";

console.log(studentName);
console.log(age);
console.log(homeTown);

