let myName="Dinuri";
console.log(myName);
myName="Sandanuwani";
console.log(myName);

const pi=3.14;
console.log(pi);

let phoneNumber;
console.log(phoneNumber);

phoneNumber="075123456";
console.log(phoneNumber);

console.log(typeof myName);
console.log(typeof phoneNumber);
console.log(typeof pi);